// Floating Recorder Toolbar - FINAL (persistence + correct Python quoting with single quotes)
(function(){
  if (window.__floating_recorder_loaded__) return;
  window.__floating_recorder_loaded__ = true;
  console.log("Floating Recorder loaded (FINAL)");

  // State
  let recording = false;
  let events = [];
  let initialUrl = location.href;

  // -----------------------------
  // Utility functions
  // -----------------------------
  function isHidden(el){
    if(!el) return true;
    if(el.type === 'hidden') return true;
    const r = el.getClientRects();
    if(r.length === 0) return true;
    const s = getComputedStyle(el);
    return s.display === 'none' || s.visibility === 'hidden' || s.opacity === '0';
  }

  function getBestSelector(el){
    if(!el) return null;
    try {
      if(el.id) return '#' + CSS.escape(el.id);
      if(el.getAttribute && el.getAttribute('name'))
        return `[name="${CSS.escape(el.getAttribute('name'))}"]`;
      if(el.getAttribute && el.getAttribute('data-testid'))
        return `[data-testid="${CSS.escape(el.getAttribute('data-testid'))}"]`;

      if(el.className && typeof el.className === 'string'){
        const classes = el.className.trim().split(/\s+/).slice(0,3).map(c => CSS.escape(c)).join('.');
        if(classes) return '.' + classes;
      }

      const p = el.parentElement;
      if(p){
        const nodes = Array.from(p.children);
        const idx = nodes.indexOf(el)+1;
        return `${p.tagName.toLowerCase()} > ${el.tagName.toLowerCase()}:nth-child(${idx})`;
      }
    } catch(err){
      // fall through
    }
    return el.tagName ? el.tagName.toLowerCase() : null;
  }

  function describe(el){
    return {
      tag: el?.tagName?.toLowerCase(),
      type: el?.getAttribute?.("type") || null,
      selector: getBestSelector(el),
      hidden: isHidden(el)
    };
  }

  // -----------------------------
  // UI (toolbar)
  // -----------------------------
  const toolbarId = '__floating_recorder_toolbar__';
  if(document.getElementById(toolbarId)) {
    // If toolbar already exists (because of single-page app re-inject), try to restore state from storage
    restoreStateFromStorage();
    return;
  }

  const container = document.createElement('div');
  container.id = toolbarId;

  const css = document.createElement('style');
  css.textContent = `
    #${toolbarId} {
      position: fixed; left: 12px; top: 80px; width: 360px;
      z-index: 2147483647; background: #fff; border:1px solid #ccc;
      box-shadow:0 6px 18px rgba(0,0,0,0.12); padding:10px;
      font-family: Arial, sans-serif; border-radius:6px;
    }
    #${toolbarId} h4 { margin:0 0 8px 0; font-size:16px; }
    #${toolbarId} button { width:48%; padding:8px; margin:4px 1%; }
    #${toolbarId} select, #${toolbarId} textarea { width:100%; box-sizing:border-box; }
    #${toolbarId} textarea {
      height:220px; margin-top:8px;
      font-family: monospace; font-size:12px; white-space: pre;
    }
    #${toolbarId} .controls { display:flex; gap:6px; }
    #${toolbarId} .footer { display:flex; gap:6px; margin-top:8px; }
    #${toolbarId} .close-btn {
      position:absolute; right:6px; top:6px;
      background:transparent; border:0; font-weight:bold; cursor:pointer;
      font-size:20px;
    }
    #${toolbarId} label { display:block; margin-top:6px; font-size:12px; }
  `;
  document.head.appendChild(css);

  container.innerHTML = `
    <button class="close-btn" title="Close">×</button>
    <h4>Recorder</h4>

    <div class="controls">
      <button id="rec_start">Start Recording</button>
      <button id="rec_stop" disabled>Stop Recording</button>
    </div>

    <label>Format:</label>
    <select id="rec_format">
      <option value="selenium">Selenium (Python)</option>
      <option value="pw-python">Playwright (Python)</option>
      <option value="pw-js">Playwright (JS)</option>
      <option value="cypress">Cypress (JS)</option>
    </select>

    <div class="footer">
      <button id="rec_generate" disabled>Generate</button>
      <button id="rec_download" disabled>Download</button>
    </div>

    <textarea id="rec_output" placeholder="Generated script appears here..."></textarea>
  `;

  document.documentElement.appendChild(container);

  const startBtn = container.querySelector('#rec_start');
  const stopBtn = container.querySelector('#rec_stop');
  const genBtn = container.querySelector('#rec_generate');
  const dlBtn = container.querySelector('#rec_download');
  const fmt = container.querySelector('#rec_format');
  const out = container.querySelector('#rec_output');

  container.querySelector('.close-btn').onclick = ()=>{
    container.style.display = 'none';
  };

  // -----------------------------
  // Persistence helpers
  // -----------------------------
  function saveStateToStorage(){
    try{
      chrome.storage.local.set({
        recorder_state: {
          recording: recording,
          events: events,
          initialUrl: initialUrl
        }
      });
    } catch(e){
      // storage not available (rare) — ignore
    }
  }

  function clearStateFromStorage(){
    try{
      chrome.storage.local.remove('recorder_state');
    } catch(e){}
  }

  function restoreStateFromStorage(){
    try{
      chrome.storage.local.get('recorder_state', (data) => {
        const s = data?.recorder_state;
        if(s && s.recording){
          recording = true;
          events = s.events || [];
          initialUrl = s.initialUrl || initialUrl;

          // UI restore
          startBtn.disabled = true;
          stopBtn.disabled = false;
          genBtn.disabled = true;
          dlBtn.disabled = true;
          out.value = 'Recording...';

          // re-attach listeners
          document.addEventListener('click', onClick, true);
          document.addEventListener('input', onInput, true);
        } else {
          // not recording; restore events if present so Generate can use them
          events = s?.events || events;
          initialUrl = s?.initialUrl || initialUrl;
          startBtn.disabled = false;
          stopBtn.disabled = true;
          genBtn.disabled = events.length ? false : true;
          dlBtn.disabled = true;
        }
      });
    } catch(e){
      // ignore
    }
  }

  // Immediately try to restore state (handles navigation reloads)
  restoreStateFromStorage();

  // -----------------------------
  // Event capture (records event.url for navigation detection)
  // -----------------------------
  function onClick(e){
    if(!recording) return;
    if (e.target.closest('#__floating_recorder_toolbar__')) return; // ignore toolbar clicks

    const d = describe(e.target);
    if (!d.selector || d.hidden) return;

    const ev = {
      kind: 'click',
      selector: d.selector,
      text: (e.target.innerText||'').trim(),
      ts: Date.now(),
      url: location.href
    };
    events.push(ev);
    saveStateToStorage();
  }

  function onInput(e){
    if(!recording) return;
    if (e.target.closest('#__floating_recorder_toolbar__')) return; // ignore toolbar inputs

    const d = describe(e.target);
    if (!d.selector || d.hidden) return;

    const ev = {
      kind: 'input',
      selector: d.selector,
      value: e.target.value,
      ts: Date.now(),
      url: location.href
    };
    events.push(ev);
    saveStateToStorage();
  }

  // -----------------------------
  // Normalize (inserts page_wait when url changes between events)
  // -----------------------------
  function normalizeEvents(list){
    const steps = [];
    let typing = null;
    let lastSelector = null;
    let prevUrl = list.length ? list[0].url : initialUrl;

    function flush(){
      if(typing){
        steps.push({ action: 'type', target: typing.selector, value: typing.value });
        typing = null;
      }
    }

    for(const e of list){
      if(!e.selector) continue;
      // detect navigation
      if(e.url && e.url !== prevUrl){
        steps.push({ action: 'page_wait' });
        prevUrl = e.url;
        lastSelector = null; // reset last click after navigation
      }

      if(e.kind === 'input'){
        typing = { selector: e.selector, value: e.value };
      } else if(e.kind === 'click'){
        flush();
        if(lastSelector !== e.selector){
          steps.push({ action: 'click', target: e.selector });
          lastSelector = e.selector;
        }
      }
    }

    flush();
    return steps;
  }

  // -----------------------------
  // Code generation (with Python single-quote quoting for CSS selectors)
  // -----------------------------
  function safe(v){ return (v||'').replace(/"/g, '\\"'); }

  // wraps selector in single quotes for Python and escapes internal single quotes
  function pySelector(sel){
    if(!sel) return "''";
    return '\'' + sel.replace(/'/g, "\\'") + '\'';
  }

  function generateScript(format){
    const steps = normalizeEvents(events || []);
    // use initialUrl (captured at start) as launch URL
    const startUrl = initialUrl || location.href;

    const generators = {
      selenium(){
        let code = `
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

driver = webdriver.Chrome()
driver.maximize_window()
wait = WebDriverWait(driver, 15)
driver.get(${pySelector(startUrl)})

`;
        for(const s of steps){
          if(s.action === 'page_wait'){
            code += `
wait.until(lambda d: d.execute_script("return document.readyState") == "complete")
time.sleep(0.2)

`;
          }
          if(s.action === 'click'){
            code += `wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, ${pySelector(s.target)}))).click()
time.sleep(0.3)

`;
          }
          if(s.action === 'type'){
            code += `wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, ${pySelector(s.target)}))).send_keys("${safe(s.value)}")
time.sleep(0.3)

`;
          }
        }
        code += `print("Done!")\ndriver.quit()`;
        return code;
      },

      "pw-python"(){
        let code = `
from playwright.sync_api import sync_playwright

def run():
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)
        page = browser.new_page()
        page.goto(${pySelector(startUrl)})

`;
        for(const s of steps){
          if(s.action === 'page_wait'){
            code += `        page.wait_for_load_state("load")\n`;
          }
          if(s.action === 'click'){
            code += `        page.click(${pySelector(s.target)})\n`;
          }
          if(s.action === 'type'){
            code += `        page.fill(${pySelector(s.target)}, "${safe(s.value)}")\n`;
          }
        }
        code += `
        browser.close()

if __name__ == "__main__":
    run()
`;
        return code;
      },

      "pw-js"(){
        let code = `
const { chromium } = require("playwright");

(async()=>{
  const browser = await chromium.launch({ headless:false });
  const page = await browser.newPage();
  await page.goto(${pySelector(startUrl)});
`;
        for(const s of steps){
          if(s.action === 'page_wait'){
            code += `  await page.waitForLoadState("load");\n`;
          }
          if(s.action === 'click'){
            code += `  await page.click(${pySelector(s.target)});\n`;
          }
          if(s.action === 'type'){
            code += `  await page.fill(${pySelector(s.target)}, "${safe(s.value)}");\n`;
          }
        }
        code += `
  await browser.close();
})();
`;
        return code;
      },

      "cypress"(){
        let code = `
describe("Recorded Test", ()=>{ 
  it("runs", ()=>{
    cy.visit(${pySelector(startUrl)})
`;
        for(const s of steps){
          if(s.action === 'page_wait'){
            code += `    cy.document().its("readyState").should("eq","complete")\n`;
          }
          if(s.action === 'click'){
            code += `    cy.get(${pySelector(s.target)}).click()\n`;
          }
          if(s.action === 'type'){
            code += `    cy.get(${pySelector(s.target)}).type("${safe(s.value)}")\n`;
          }
        }
        code += `
  });
});
`;
        return code;
      }
    };

    return (generators[format] || generators['selenium'])();
  }

  // -----------------------------
  // Download helper ALWAYS .py
  // -----------------------------
  function downloadText(filename, text){
    const blob = new Blob([text], { type:'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  }

  dlBtn.addEventListener('click', ()=>{
    // Always .py per your request
    downloadText("automation.py", out.value || "");
  });

  // -----------------------------
  // Buttons (start/stop/generate)
  // -----------------------------
  startBtn.addEventListener('click', ()=>{
    recording = true;
    events = [];
    initialUrl = location.href;  // capture only once
    saveStateToStorage();

    startBtn.disabled = true;
    stopBtn.disabled = false;
    genBtn.disabled = true;
    dlBtn.disabled = true;
    out.value = 'Recording...';

    document.addEventListener('click', onClick, true);
    document.addEventListener('input', onInput, true);
  });

  stopBtn.addEventListener('click', ()=>{
    recording = false;
    saveStateToStorage(); // persist final events
    startBtn.disabled = false;
    stopBtn.disabled = true;
    genBtn.disabled = false;
    document.removeEventListener('click', onClick, true);
    document.removeEventListener('input', onInput, true);
    out.value = 'Recording stopped. Click Generate.';
  });

  genBtn.addEventListener('click', ()=>{
    out.value = generateScript(fmt.value);
    dlBtn.disabled = false;
  });

  // -----------------------------
  // Draggable toolbar
  // -----------------------------
  (function makeDraggable(el){
    let isDown = false, startX, startY, origX, origY;

    el.addEventListener('mousedown', (e)=>{
      if(["BUTTON","SELECT","TEXTAREA","INPUT"].includes(e.target.tagName)) return;

      isDown = true;
      startX = e.clientX;
      startY = e.clientY;

      const rect = el.getBoundingClientRect();
      origX = rect.left;
      origY = rect.top;

      document.body.style.userSelect = "none";
    });

    window.addEventListener('mousemove', (e)=>{
      if(!isDown) return;
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;
      el.style.left = Math.max(4, origX + dx) + "px";
      el.style.top = Math.max(4, origY + dy) + "px";
    });

    window.addEventListener('mouseup', ()=>{
      isDown = false;
      document.body.style.userSelect = "auto";
    });

  })(container);

  // Export API for debugging (optional)
  window.__floating_recorder = {
    getEvents: ()=>events.slice(),
    isRecording: ()=>recording,
    getInitialUrl: ()=>initialUrl,
    clear: ()=>{ events=[]; initialUrl=location.href; clearStateFromStorage(); }
  };

})(); // IIFE end
